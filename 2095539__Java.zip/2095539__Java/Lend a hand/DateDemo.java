package com.cognizant;

import java.util.Date;

public class DateDemo {

	public static void main(String[] args) {
		Date d=new Date();
		System.out.println("Today date is "+d);

	}

}
