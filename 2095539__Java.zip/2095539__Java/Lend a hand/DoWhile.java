package com.cognizant;

import java.util.Scanner;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   int a =1;
   
   do{
	   System.out.println(a);
	   a++;
	   
   }
   while(a<10);
	}

}
